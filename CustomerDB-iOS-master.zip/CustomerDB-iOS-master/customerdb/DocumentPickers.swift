//
//  DocumentPickers.swift
//  Copyright © 2020 Georg Sieber. All rights reserved.
//

import Foundation
import UIKit

class CustomerDocumentPickerViewController : UIDocumentPickerViewController {
    
}
class VoucherDocumentPickerViewController : UIDocumentPickerViewController {
    
}
class AppointmentDocumentPickerViewController : UIDocumentPickerViewController {
    
}
